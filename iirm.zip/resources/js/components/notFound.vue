<template>
    <h1>Not Found Page</h1>
    <div>
        <router-link to="/">Home Page</router-link>
    </div>
</template>