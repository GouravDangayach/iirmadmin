<script setup>
import headerVue from './header.vue';
import sidebarVue from './sidebar.vue';
</script>
<template>
    <div class="base">
        <headerVue />
        <sidebarVue />
    </div>
</template>
<style>
    @import './base.css';
</style>